
insert into songs values(0, "Silence", "Field Music", "2020-01-10", "Easy Listening", 40);
insert into songs values(1, "Coffee Or Wine", "Field Music", "2020-01-10", "Easy Listening", 183);
insert into songs values(2, "Best Kept Garden", "Field Music", "2020-01-10", "Easy Listening", 174);
insert into songs values(3, "I Thought You Were Something Else", "Field Music", "2020-01-10", "Easy Listening", 72);
insert into songs values(4, "Between Nations", "Field Music", "2020-01-10", "Easy Listening", 245);
insert into songs values(5, "A Change of Heir", "Field Music", "2020-01-10", "Easy Listening", 159);
insert into songs values(6, "Do You Read Me?", "Field Music", "2020-01-10", "Easy Listening", 260);
insert into songs values(7, "From a Dream, Into My Arms", "Field Music", "2020-01-10", "Easy Listening", 80);
insert into songs values(8, "Beyond That of Courtesy", "Field Music", "2020-01-10", "Easy Listening", 133);
insert into songs values(9, "A Shot to the Arm", "Field Music", "2020-01-10", "Easy Listening", 152);
insert into songs values(10, "A Common Language Pt. 1", "Field Music", "2020-01-10", "Easy Listening", 121);
insert into songs values(11, "A Common Language Pt. 2", "Field Music", "2020-01-10", "Easy Listening", 32);
insert into songs values(12, "Nikon Pt. 1", "Field Music", "2020-01-10", "Easy Listening", 154);
insert into songs values(13, "Nikon Pt. 2", "Field Music", "2020-01-10", "Easy Listening", 54);
insert into songs values(14, "If the Wind Blows Towards the Hospital", "Field Music", "2020-01-10", "Easy Listening", 87);
insert into songs values(15, "Only in a Man's World", "Field Music", "2020-01-10", "Easy Listening", 166);
insert into songs values(16, "Money Is a Memory", "Field Music", "2020-01-10", "Easy Listening", 213);
insert into songs values(17, "An Independent State", "Field Music", "2020-01-10", "Easy Listening", 160);