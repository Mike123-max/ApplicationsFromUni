DELIMITER $$

CREATE TRIGGER client_before_update
BEFORE UPDATE   
ON clients FOR EACH ROW
BEGIN
INSERT INTO clientHistory(clientHistoryID,
clientID,
clientFirstName,  
clientLastName,
clientUsername,
clientPassword,  
clientEmail,
clientPhone, 
clientAddress,  
audit,  
clientHistoryTimeStamp)
VALUES(NULL,
old.clientID,
old.clientFirstName,  
old.clientLastName,
old.clientUsername,
old.clientPassword,  
old.clientEmail,
old.clientPhone, 
old.clientAddress,  
"UPDATED",  
NOW());
END; $$

CREATE TRIGGER staff_before_update
BEFORE UPDATE   
ON staff FOR EACH ROW
BEGIN
INSERT INTO staffHistory(staffHistoryID,
staffID,
staffFirstName,  
staffLastName,
staffDepartmentID,
staffJobTitle,  
staffPayGrade,
staffUsername, 
staffPassword,  
audit,  
staffHistoryTimeStamp)
VALUES(NULL,
old.staffID,
old.staffFirstName,  
old.staffLastName,
old.staffDepartmentID,
old.staffJobTitle,  
old.staffPayGrade,
old.staffUsername, 
old.staffPassword,  
"UPDATED",  
NOW());
END; $$


CREATE TRIGGER client_before_delete
BEFORE DELETE   
ON clients FOR EACH ROW
BEGIN
INSERT INTO clientHistory(clientHistoryID,
clientID,
clientFirstName,  
clientLastName,
clientUsername,
clientPassword,  
clientEmail,
clientPhone, 
clientAddress,  
audit,  
clientHistoryTimeStamp)
VALUES(NULL,
old.clientID,
old.clientFirstName,  
old.clientLastName,
old.clientUsername,
old.clientPassword,  
old.clientEmail,
old.clientPhone, 
old.clientAddress,  
"DELETED",  
NOW());
END; $$

CREATE TRIGGER staff_before_delete
BEFORE DELETE   
ON staff FOR EACH ROW
BEGIN
INSERT INTO staffHistory(staffHistoryID,
staffID,
staffFirstName,  
staffLastName,
staffDepartmentID,
staffJobTitle,  
staffPayGrade,
staffUsername, 
staffPassword,  
audit,  
staffHistoryTimeStamp)
VALUES(NULL,
old.staffID,
old.staffFirstName,  
old.staffLastName,
old.staffDepartmentID,
old.staffJobTitle,  
old.staffPayGrade,
old.staffUsername, 
old.staffPassword,  
"DELETED",  
NOW());
END; $$

