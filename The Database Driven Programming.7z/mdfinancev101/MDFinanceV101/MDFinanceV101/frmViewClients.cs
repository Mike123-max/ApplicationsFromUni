﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MDFinanceV101
{
    public partial class frmViewClients : Form
    {
        private string conn;
        private MySqlConnection connect;
        public frmViewClients()
        {
            InitializeComponent();
        }
        private void db_connection()
        {
            try
            {
                conn = "Server=localhost;Database=michaeld_ddap;Uid=michaeld_aoop;Pwd=1704206;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }
        private void frmViewClients_Load(object sender, EventArgs e)
        {
            db_connection();
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandText = "CALL viewClients()";
            cmd.Connection = connect;
            MySqlDataAdapter myAdapter = new MySqlDataAdapter();
            myAdapter.SelectCommand = cmd;
            DataTable dTable = new DataTable();
            myAdapter.Fill(dTable);
            ClientsResult.DataSource = dTable;
        }
    }
}
