﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MDFinanceV101
{
    public partial class frmStaffAdvisors : Form
    {
        private string conn;
        private MySqlConnection connect;
        public frmStaffAdvisors()
        {
            InitializeComponent();
        }

        private void db_connection()
        {
            try
            {
                conn = "Server=localhost;Database=michaeld_ddap;Uid=michaeld_aoop;Pwd=1704206;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }
        private void frmAdvisor_Load(object sender, EventArgs e)
        {
            db_connection();
            MySqlCommand cmd1 = new MySqlCommand();
            cmd1.CommandText = "CALL Advisors()";
            cmd1.Connection = connect;
            MySqlDataAdapter myAdapter1 = new MySqlDataAdapter();
            myAdapter1.SelectCommand = cmd1;
            DataTable dTable1 = new DataTable();
            myAdapter1.Fill(dTable1);
            StaffResult.DataSource = dTable1;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            db_connection();
            MySqlCommand cmd1 = new MySqlCommand();
            cmd1.CommandText = "CALL TenHighest(\"" + txtMonth.Text + "\")";
            cmd1.Connection = connect;
            MySqlDataAdapter myAdapter1 = new MySqlDataAdapter();
            myAdapter1.SelectCommand = cmd1;
            DataTable dTable1 = new DataTable();
            myAdapter1.Fill(dTable1);
            StaffResult.DataSource = dTable1;
        }
    }
}
