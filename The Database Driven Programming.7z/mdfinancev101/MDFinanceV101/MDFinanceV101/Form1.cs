﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MDFinanceV101
{
    public partial class frmMain : Form
    {
        private String conn;
        private MySqlConnection connect;
        public frmMain()
        {
            InitializeComponent();
        }

        private void db_connection()
        {
            try
            {
                conn = "Server=127.0.0.1;Database=michaeld_ddap;Uid=michaeld_aoop;Pwd=1704206;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        private void btnViewStaff_Click(object sender, EventArgs e)
        {
            frmViewStaff staff = new frmViewStaff();
            staff.Show();
        }

        private void btnViewClientsSavings_Click(object sender, EventArgs e)
        {
            frmViewClientsSavings clientsSavings = new frmViewClientsSavings();
            clientsSavings.Show();
        }

        private void btnInsertStaff_Click(object sender, EventArgs e)
        {
            frmInsertStaff insert = new frmInsertStaff();
            insert.Show();
        }

        private void btnUpdateStaff_Click(object sender, EventArgs e)
        {
            frmPickCustomer update = new frmPickCustomer();
            update.Show();
        }

        private void btnSavings_Click(object sender, EventArgs e)
        {
            frmViewSavings Savings = new frmViewSavings();
            Savings.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmTenPercent clientPercent = new frmTenPercent();
            clientPercent.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmClientsAccounts clientAccount = new frmClientsAccounts();
            clientAccount.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmStaffPaygradeX paygrades = new frmStaffPaygradeX();
            paygrades.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmStaffAdvisors advisor = new frmStaffAdvisors();
            advisor.Show();
        }
    }
}
