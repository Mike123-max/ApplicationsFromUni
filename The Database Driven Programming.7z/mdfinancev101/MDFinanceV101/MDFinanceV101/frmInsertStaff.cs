﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MDFinanceV101
{
    public partial class frmInsertStaff : Form
    {
        private string conn;
        private MySqlConnection connect;
        public frmInsertStaff()
        {
            InitializeComponent();
        }

        private void db_connection()
        {
            try
            {
                conn = "Server=localhost;Database=michaeld_ddap;Uid=michaeld_aoop;Pwd=1704206;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Object department = cboDepartmentID.SelectedItem;
            Object paygrade = cboPayGradeI.SelectedItem;
            string staffpaygrade = paygrade.ToString();

            int departmentID = 0;
            string fname = txtFirstName.Text;
            string lname = txtLastName.Text;
            string job = txtJobTitleI.Text;
            string username = txtUsernameI.Text;
            string password = txtPasswordI.Text;


            db_connection();
            MySqlCommand cmd = new MySqlCommand();
            string ID = department.ToString();
            if (ID == "1 | HR")
            {
                departmentID = 1;
            }

            else if (ID == "2 | Finance")
            {
                departmentID = 2;
            }

           else  if (ID == "3 | Advice")
            {
                departmentID = 3;
            }

            else if (ID == "4 | Advertising")
            {
                departmentID = 4;
            }

            cmd.CommandText = "INSERT INTO staff (staffID, staffFirstName, staffLastName, staffDepartmentID, staffJobTitle, staffPayGrade, staffUsername, staffPassword) VALUES(" +
                                "NULL, " +
                                "\"" + fname + "\", " +
                                "\"" + lname + "\", " +
                                 + departmentID + ", "+
                                "\"" + job + "\", " +
                                "\"" + staffpaygrade+ "\", " +
                                "\"" + username + "\", " +
                                "\"" + password + "\" " +
                                ")";

            // Run the query
            cmd.Connection = connect;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            MessageBox.Show("Staff Inserted");

        }
    }
}
