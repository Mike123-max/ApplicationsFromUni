﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MDFinanceV101
{
    public partial class frmUpdateDetails : Form
    {
        private string conn;
        private MySqlConnection connect;
        private static int departmentID;
        public frmUpdateDetails()
        {
            
            InitializeComponent();
            txtFirstName.Text = frmPickCustomer.staffName;
            txtLastName.Text = frmPickCustomer.staffLastName;
        }
        private void db_connection()
        {
            try
            {
                conn = "Server=localhost;Database=michaeld_ddap;Uid=michaeld_aoop;Pwd=1704206;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Object department = cboDepartmentID.SelectedItem;
            Object paygrade = cboPayGrade.SelectedItem;
            string staffpaygrade = paygrade.ToString();

            int departmentID = 0;
            string fname = txtFirstName.Text;
            string lname = txtLastName.Text;
            string job = txtJobTitle.Text;
            string username = txtUsername.Text;
            string password = txtPassword.Text;


            db_connection();
            MySqlCommand cmd = new MySqlCommand();
            string departmentIDs = department.ToString();
            string staffID = frmPickCustomer.staffID;
            if (departmentIDs == "1 | HR")
            {
                departmentID = 1;
            }

            else if (departmentIDs == "2 | Finance")
            {
                departmentID = 2;
            }

            else if (departmentIDs == "3 | Advice")
            {
                departmentID = 3;
            }

            else if (departmentIDs == "4 | Advertising")
            {
                departmentID = 4;
            }

            cmd.CommandText = "UPDATE staff SET staffFirstName = \"" + fname + "\"," +
                "staffLastName = \"" + lname + "\", " +
                "staffDepartmentID = \"" + departmentID + "\", " +
                "staffJobTitle = \"" + job + "\", " +
                "staffPayGrade = \"" + paygrade + "\", " +
                "staffUsername = \"" + username + "\"," +
                "staffPassword = \"" + password + "\" WHERE staffID = " + staffID;

            // Run the query
            cmd.Connection = connect;
            MySqlDataReader myReader;
            myReader = cmd.ExecuteReader();
            MessageBox.Show("Staff Updated");
        }
    }
}
