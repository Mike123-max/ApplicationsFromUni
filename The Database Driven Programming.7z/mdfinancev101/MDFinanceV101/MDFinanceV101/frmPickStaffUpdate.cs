﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MDFinanceV101
{
    public partial class frmPickCustomer : Form
    {
        // the variables that will hold the database connection
        private string conn;
        private MySqlConnection connect;

        public static string staffName;
        public static string staffLastName;
        public static string staffID;

        public frmPickCustomer()
        {
            InitializeComponent();
            refreshData();
        }

        // A method (function) to create the database connection
        private void db_connection()
        {
            try
            {
                conn = "Server=localhost;Database=michaeld_ddap;Uid=michaeld_aoop;Pwd=1704206;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }
            catch (MySqlException e)
            {
                throw;
            }
        }

        public void refreshData ()
        {
            // Open the database connection
            db_connection();
            // Create a new database command
            MySqlCommand cmd = new MySqlCommand();
            // Set the query in the database command
            cmd.CommandText = "SELECT staffID, staffFirstName, staffLastName FROM staff";
            // Set the connection for the database command
            cmd.Connection = connect;

            // Fill the combo box with the data from the query
            MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            myAdapter.Fill(ds, "staff");
            comboStaffList.DisplayMember = "staffFirstName";
            comboStaffList.ValueMember = "staffID";
            comboStaffList.DataSource = ds.Tables["staff"];
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmPickCustomer_Load(object sender, EventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            frmUpdateDetails frm9 = new frmUpdateDetails();
            frm9.Show();
            this.Close();
        }

        private void comboStaffList_SelectedIndexChanged(object sender, EventArgs e)
        {
            // drv holds the ID of the row of data
            DataRowView drv = comboStaffList.SelectedItem as DataRowView;

            // Show drv when we pick something from the box - for testing
            label1.Text = drv.Row["staffID"].ToString();

            // Set the company ID for the item selected in the list
            staffName = drv.Row["staffFirstName"].ToString();
            staffLastName = drv.Row["staffLastName"].ToString();
            staffID = drv.Row["staffID"].ToString();
        }
    }
}
