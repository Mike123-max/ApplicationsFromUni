﻿namespace MDFinanceV101
{
    partial class frmInsertStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInsertStaff));
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnInsert = new System.Windows.Forms.Button();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstNameI = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastNameI = new System.Windows.Forms.Label();
            this.cboDepartmentID = new System.Windows.Forms.ComboBox();
            this.lblDepartmentIDI = new System.Windows.Forms.Label();
            this.txtJobTitleI = new System.Windows.Forms.TextBox();
            this.lblJobTitleI = new System.Windows.Forms.Label();
            this.cboPayGradeI = new System.Windows.Forms.ComboBox();
            this.lblPayGradeI = new System.Windows.Forms.Label();
            this.txtUsernameI = new System.Windows.Forms.TextBox();
            this.txtPasswordI = new System.Windows.Forms.TextBox();
            this.lblUsernameI = new System.Windows.Forms.Label();
            this.lblPasswordI = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(280, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 38);
            this.label2.TabIndex = 6;
            this.label2.Text = "MD Finance";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(500, 30);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 69);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(200, 30);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 69);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btnInsert
            // 
            this.btnInsert.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.Location = new System.Drawing.Point(321, 406);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(102, 35);
            this.btnInsert.TabIndex = 7;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(363, 151);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(127, 22);
            this.txtFirstName.TabIndex = 8;
            // 
            // lblFirstNameI
            // 
            this.lblFirstNameI.AutoSize = true;
            this.lblFirstNameI.Location = new System.Drawing.Point(274, 154);
            this.lblFirstNameI.Name = "lblFirstNameI";
            this.lblFirstNameI.Size = new System.Drawing.Size(84, 17);
            this.lblFirstNameI.TabIndex = 9;
            this.lblFirstNameI.Text = "First Name: ";
            this.lblFirstNameI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(363, 179);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(127, 22);
            this.txtLastName.TabIndex = 10;
            // 
            // lblLastNameI
            // 
            this.lblLastNameI.AutoSize = true;
            this.lblLastNameI.Location = new System.Drawing.Point(274, 182);
            this.lblLastNameI.Name = "lblLastNameI";
            this.lblLastNameI.Size = new System.Drawing.Size(84, 17);
            this.lblLastNameI.TabIndex = 11;
            this.lblLastNameI.Text = "Last Name: ";
            this.lblLastNameI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboDepartmentID
            // 
            this.cboDepartmentID.FormattingEnabled = true;
            this.cboDepartmentID.Items.AddRange(new object[] {
            "1 | HR",
            "2 | Finance",
            "3 | Advice",
            "4 | Advertising"});
            this.cboDepartmentID.Location = new System.Drawing.Point(363, 207);
            this.cboDepartmentID.Name = "cboDepartmentID";
            this.cboDepartmentID.Size = new System.Drawing.Size(127, 24);
            this.cboDepartmentID.TabIndex = 12;
            // 
            // lblDepartmentIDI
            // 
            this.lblDepartmentIDI.AutoSize = true;
            this.lblDepartmentIDI.Location = new System.Drawing.Point(251, 210);
            this.lblDepartmentIDI.Name = "lblDepartmentIDI";
            this.lblDepartmentIDI.Size = new System.Drawing.Size(107, 17);
            this.lblDepartmentIDI.TabIndex = 13;
            this.lblDepartmentIDI.Text = "Department ID: ";
            this.lblDepartmentIDI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtJobTitleI
            // 
            this.txtJobTitleI.Location = new System.Drawing.Point(363, 237);
            this.txtJobTitleI.Name = "txtJobTitleI";
            this.txtJobTitleI.Size = new System.Drawing.Size(127, 22);
            this.txtJobTitleI.TabIndex = 14;
            // 
            // lblJobTitleI
            // 
            this.lblJobTitleI.AutoSize = true;
            this.lblJobTitleI.Location = new System.Drawing.Point(284, 240);
            this.lblJobTitleI.Name = "lblJobTitleI";
            this.lblJobTitleI.Size = new System.Drawing.Size(74, 17);
            this.lblJobTitleI.TabIndex = 15;
            this.lblJobTitleI.Text = "Job Title:  ";
            this.lblJobTitleI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboPayGradeI
            // 
            this.cboPayGradeI.FormattingEnabled = true;
            this.cboPayGradeI.Items.AddRange(new object[] {
            "AA",
            "AB",
            "AC",
            "AD",
            "AE",
            "AF",
            "AG",
            "AH"});
            this.cboPayGradeI.Location = new System.Drawing.Point(363, 266);
            this.cboPayGradeI.Name = "cboPayGradeI";
            this.cboPayGradeI.Size = new System.Drawing.Size(127, 24);
            this.cboPayGradeI.TabIndex = 16;
            // 
            // lblPayGradeI
            // 
            this.lblPayGradeI.AutoSize = true;
            this.lblPayGradeI.Location = new System.Drawing.Point(271, 269);
            this.lblPayGradeI.Name = "lblPayGradeI";
            this.lblPayGradeI.Size = new System.Drawing.Size(88, 17);
            this.lblPayGradeI.TabIndex = 17;
            this.lblPayGradeI.Text = "Pay Grade:  ";
            this.lblPayGradeI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtUsernameI
            // 
            this.txtUsernameI.Location = new System.Drawing.Point(363, 297);
            this.txtUsernameI.Name = "txtUsernameI";
            this.txtUsernameI.Size = new System.Drawing.Size(127, 22);
            this.txtUsernameI.TabIndex = 18;
            // 
            // txtPasswordI
            // 
            this.txtPasswordI.Location = new System.Drawing.Point(363, 325);
            this.txtPasswordI.Name = "txtPasswordI";
            this.txtPasswordI.Size = new System.Drawing.Size(127, 22);
            this.txtPasswordI.TabIndex = 19;
            // 
            // lblUsernameI
            // 
            this.lblUsernameI.AutoSize = true;
            this.lblUsernameI.Location = new System.Drawing.Point(272, 300);
            this.lblUsernameI.Name = "lblUsernameI";
            this.lblUsernameI.Size = new System.Drawing.Size(85, 17);
            this.lblUsernameI.TabIndex = 20;
            this.lblUsernameI.Text = "Username:  ";
            this.lblUsernameI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPasswordI
            // 
            this.lblPasswordI.AutoSize = true;
            this.lblPasswordI.Location = new System.Drawing.Point(276, 328);
            this.lblPasswordI.Name = "lblPasswordI";
            this.lblPasswordI.Size = new System.Drawing.Size(81, 17);
            this.lblPasswordI.TabIndex = 21;
            this.lblPasswordI.Text = "Password:  ";
            this.lblPasswordI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmInsertStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 453);
            this.Controls.Add(this.lblPasswordI);
            this.Controls.Add(this.lblUsernameI);
            this.Controls.Add(this.txtPasswordI);
            this.Controls.Add(this.txtUsernameI);
            this.Controls.Add(this.lblPayGradeI);
            this.Controls.Add(this.cboPayGradeI);
            this.Controls.Add(this.lblJobTitleI);
            this.Controls.Add(this.txtJobTitleI);
            this.Controls.Add(this.lblDepartmentIDI);
            this.Controls.Add(this.cboDepartmentID);
            this.Controls.Add(this.lblLastNameI);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lblFirstNameI);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmInsertStaff";
            this.Text = "MD Finance";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstNameI;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastNameI;
        private System.Windows.Forms.ComboBox cboDepartmentID;
        private System.Windows.Forms.Label lblDepartmentIDI;
        private System.Windows.Forms.TextBox txtJobTitleI;
        private System.Windows.Forms.Label lblJobTitleI;
        private System.Windows.Forms.ComboBox cboPayGradeI;
        private System.Windows.Forms.Label lblPayGradeI;
        private System.Windows.Forms.TextBox txtUsernameI;
        private System.Windows.Forms.TextBox txtPasswordI;
        private System.Windows.Forms.Label lblUsernameI;
        private System.Windows.Forms.Label lblPasswordI;
    }
}