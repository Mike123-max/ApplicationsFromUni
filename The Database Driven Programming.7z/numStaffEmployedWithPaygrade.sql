/**/
select 
count(staffID) as TotalNumberStaffWithPayGrade, 
staffPayGrade as PayGradeSelected 
from staff 
where staffPayGrade="AC"
group by staffPayGrade