/*select info */

select 
/*select info from clients table */
clients.clientFirstName,
clients.clientLastName,
/* select clientID from accounts table*/
COUNT(accounts.clientID) as NumAccounts,
/* select the amount saved from the savings sum them */ 
SUM(savings.amountSaved) as TotalAmountSaved
from clients
/*join the accounts table to the clients table */
left JOIN accounts
on clients.clientID=accounts.clientID
/*join the savings table to the accounts table */
left join savings
on accounts.savingID=savings.savingID

/* group by clients ID */
group by clients.clientID
having sum(savings.amountSaved) >= 9000000;