delimiter $$








/* procedure for viewing staff members*/
create procedure viewStaff()
/* begin the procedure */
begin
/* select */
select
/* combine first and last names together to make full name */
 CONCAT(staffFirstName, " ", staffLastName) AS staffName,
 /* staff paygrade */
 staffPayGrade as payGrade,
 /* staff job */
 staffJobTitle as job
 from staff;
end $$
















 /* Procedure for viewing clients */
create procedure viewClients()
 /* start the queries */
begin
 /* start selecting */
select
/* combine first and last */
concat(clientFirstName," ", clientLastName) as ClientName,
 /* view clients email */
clientEmail as Email,
/* view clients phone */
clientPhone as Phone,
/* view address of this client */
clientAddress as Address

from clients;
end $$














/* procedure to find the client */
CREATE PROCEDURE findClient(IN searchStr VARCHAR(50)) 
/* begin the procedure */
BEGIN
/* start selection */
SELECT
/* combine clients name */
CONCAT(clientFirstName, " ", clientLastName) AS ClientName,
/* view clients email */
clientEmail AS Email,
/* view clients phone number */
clientPhone AS Phone,
/* view  clients address */
clientAddress AS Address
/* selected from  */
FROM clients
/* search clients based on user input */
WHERE CONCAT(clientFirstName, " ", clientLastName) LIKE CONCAT('%', searchStr, '%');
/* end procedure */
END $$















/* procedure to find staff members */
CREATE PROCEDURE findStaff(IN searchStr VARCHAR(50)) 
/* start query */
BEGIN
/* select the following */
SELECT
/* concatination of staff first name and last name */
CONCAT(staffFirstName, " ", staffLastName) AS StaffName,
/* staff paygrade */
staffPayGrade as PayGrade,
/* job title of staff */
staffJobTitle as Job
/* from the staff table */
FROM staff
/* where the staff name is like the user input */
WHERE CONCAT(staffFirstName, " ", staffLastName) LIKE CONCAT('%', searchStr, '%');
/* end the procedure */
END $$
delimiter ;