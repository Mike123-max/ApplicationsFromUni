DELIMITER $$
CREATE DEFINER=`michaeld_aoop`@`127.0.0.1` PROCEDURE `findPaygrade`(IN searchStr VARCHAR(50))
begin
/* select required info */
select 
staffFirstName,
staffLastName,
/* make it so this column makes sense */
staffPayGrade as PayGradeSelected 
from staff 
/*set condition to see all staff from one paygrade*/
where staffPayGrade LIKE CONCAT('%', searchStr, '%')
/* group by client */
group by clients.clientID;
end$$
DELIMITER ;