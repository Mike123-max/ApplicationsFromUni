create table savings(
savingID int auto_increment,
amountSaved double,
primary key(savingID));

create table accounts(
accountID int auto_increment,
accountName varchar(1000),
FOREIGN KEY (clientID) REFERENCES clients(clientID),
FOREIGN KEY (savingID) REFERENCES savings(savingID),
accountInterest double,
primary key(accountID));

create table billTypes(
billTypeId int auto_increment,
billType varchar(500),
primary key(billTypeID));

create table billOccurrences(
billOccurrenceID int auto_increment,
BillOccurrence varchar(500),
primary key(billOccurrenceID));

create table bills(
billID int auto_increment,
billName varchar(200),
FOREIGN KEY (billTypeID) REFERENCES billTypes(billTypeID),
billDueDate date,
FOREIGN KEY (billOccurrenceID) REFERENCES billOccurrences(billOccurrenceID),
primary key(billID));

create table salaries(
payGrade varchar(2) unique,
salary double,
primary key(payGrade));

create table departments(
departmentID int auto_increment,
departmentName varchar(200),
primary key(departmentID));

create table staff(
staffID int auto_increment,
staffFirstName varchar(200),
staffLastName varchar(200),
FOREIGN KEY (departmentID) REFERENCES departments(departmentID),
staffJobTitle varchar(500),
FOREIGN KEY (payGrade) REFERENCES salaries(payGrade),
primary key(staffID))