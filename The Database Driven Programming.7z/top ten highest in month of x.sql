/* select required info */
select
/*select info from advisors table */
advisors.staffAdvisor,
/*select info from staff table */
staff.staffFirstName,
staff.staffLastName,
/*see client staff advises */
count(advisors.clientStaffAdvices) as numClientsAdvised,
advisors.monthAdvised
from advisors
/*join staff table to advisors table */
left join staff
on advisors.staffAdvisor=staff.staffID
/*join clients table to staff table */
left join clients
on advisors.clientStaffAdvices=clients.clientID
/*set condition so we can only see one month */
where advisors.monthAdvised="december" 
/* group by advisor, then by month */
group by advisors.staffAdvisor, advisors.monthAdvised
/*order by amount of clients advised from highest to lowest */
order by count(advisors.clientStaffAdvices) DESC
/*Limit to three results */
LIMIT 3