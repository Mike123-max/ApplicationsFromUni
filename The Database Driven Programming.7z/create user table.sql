create table client(
clientID int auto_increment,
clientFirstName varchar(200),
clientLastName varchar(200),
clientUsername varchar(200) unique,
clientPassword varchar(20) unique,
clientEmail varchar(200) unique,
clientPhone varchar(15),
clientAddress varchar(5000),
primary key(clientID));