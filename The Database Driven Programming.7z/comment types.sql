/* this is an in-line comment */

# This is a single line comment

-- This is also a single line comment

/*
This is a 
multiline comment
*/