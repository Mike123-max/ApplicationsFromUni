/* term used to select columns*/
select
/*The accounts name, which is the type of the account*/
accounts.accountName,
/*the account ID */
count(accounts.accountID) as TotalNumAccounts
from accounts
group by accounts.accountName