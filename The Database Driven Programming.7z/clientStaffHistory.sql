create table staffHistory(
staffHistoryID int auto_increment primary key,
staffID int,
staffFirstName varchar(200),
staffLastName varchar(200),
staffDepartmentID int,
staffJobTitle varchar(500),
staffPayGrade varchar(2),
staffUsername varchar(200),
staffPassword varchar(200),
audit varchar(10),
staffHistoryTimeStamp datetime);

create table clientHistory(
clientHistoryID int auto_increment primary key,
clientID int,
clientFirstName varchar(200),
clientLastName varchar(200),
clientUsername varchar(200),
clientPassword varchar(20),
clientEmail varchar(200),
clientPhone varchar(20),
clientAddress varchar(5000),
audit varchar(10),
clientHistoryTimeStamp datetime)

