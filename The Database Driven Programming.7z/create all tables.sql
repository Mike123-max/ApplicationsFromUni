/*
#############################################################
#############################################################
##                                                         ##
##  Name Of File: create all tables.sql                    ##
##  What it does: creates tables for finance busuness      ##
##  Created By: 1704206                                    ##
##  Date Created: 04/02/2019                               ##
##  Date Modified: 05/02/2019                              ##
##                                                         ##
#############################################################
#############################################################
*/
# create the clients table
create table clients(
clientID int auto_increment unique, /* client's ID, automatically increases as entries come in, used to identify client and to search */
clientFirstName varchar(200), /* client's First name, allow for 200 characters, which should be plenty for most people */
clientLastName varchar(200), /* client's Last name, allow for 200 characters, which should be plenty for most people */
clientUsername varchar(200) unique, /* client's username, allow for 200 characters making it unlikely that usernames will be the same, make it unique to allow no duplicates */
clientPassword varchar(20) unique, /* client's password, allow for 200 characters making it unlikely that passwords will be the same, make it unique to allow no duplicates */
clientEmail varchar(200), /* client's email, allow for 200 characters making it unlikely that emails will be the same, make it unique to allow no duplicates */
clientPhone varchar(20), /* phone's username, allow for 15 characters 11 digit phone number with room for spaces and code in brackets i.e. (+44) 01234 567 890 */
clientAddress varchar(5000), /* Client's address allow for all lines of address, each separated by comma */
primary key(clientID)); /* Make the client's id the primary key for this table */ 

#creates the table for the savings of their customers
create table savings( 
savingID int auto_increment unique, /* id for savings, */
amountSaved double, /* amount client has saved. Different people might have different amounts saved */
primary key(savingID)); /* savingID is primary key */

#accounts table
create table accounts(
accountID int auto_increment unique, /* ID of account, automatic incrementing */
accountName varchar(1000), /*  */
clientID int, /* */
savingID int, /* */
FOREIGN KEY (clientID) REFERENCES clients(clientID) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
FOREIGN KEY (savingID) REFERENCES savings(savingID) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
accountInterest double, /*  */
primary key(accountID)); /*   */

#table
create table billTypes(
billTypeId int auto_increment, /*  */
billType varchar(500), /*  */
primary key(billTypeID)); /*  */

#table
create table billOccurrences(
billOccurrenceID int auto_increment unique, /*  */
BillOccurrence varchar(500), /*  */
primary key(billOccurrenceID)); /*   */


#table
create table bills(
billID int auto_increment unique, /*  */
billName varchar(200), /*  */
billTypeID int, /* */
FOREIGN KEY (billTypeID) REFERENCES billTypes(billTypeID) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
BillBelongsToClientID int, /*  */
FOREIGN KEY (BillBelongsToClientID) REFERENCES clients(clientID) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
billDueDate date, /*  */
billOccurrenceID int, /*  */
FOREIGN KEY (billOccurrenceID) REFERENCES billOccurrences(billOccurrenceID) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
primary key(billID)); /*  */

#table
create table salaries(
payGrade varchar(2) unique, /*  */
salary double, /*  */
primary key(payGrade)); /*  */

#table
create table departments(
departmentID int auto_increment unique, /*  */
departmentName varchar(200),
accessControl varchar(200), /*  */
primary key(departmentID)); /*  */

#table
create table staff(
staffID int auto_increment unique, /*  */
staffFirstName varchar(200), /*  */
staffLastName varchar(200), /*  */
staffDepartmentID int, /*  */
FOREIGN KEY (staffDepartmentID) REFERENCES departments(departmentID) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
staffJobTitle varchar(500), /*  */
staffPayGrade varchar(2), /*  */
staffUsername varchar(200) unique,
staffPassword varchar(200) unique,
FOREIGN KEY (staffPayGrade) REFERENCES salaries(payGrade) ON DELETE NO ACTION ON UPDATE NO ACTION, /*  */
primary key(staffID)); /*  */

create table advisors(
advisorID int auto_increment unique,
staffAdvisor int,
clientStaffAdvices int,
monthAdvised varchar(9),
FOREIGN KEY(staffAdvisor) REFERENCES staff(staffID) ON DELETE NO ACTION ON UPDATE NO ACTION,
FOREIGN KEY(clientStaffAdvices) REFERENCES clients(clientID) ON DELETE NO ACTION ON UPDATE NO ACTION,
primary key(advisorID));
