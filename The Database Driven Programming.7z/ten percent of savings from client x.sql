DELIMITER $$
CREATE DEFINER=`michaeld_aoop`@`127.0.0.1` PROCEDURE `findTenPercentClientsSavings`(IN searchStr VARCHAR(50))

/* select info */
select 
/* select from clients */
clients.clientID,
clients.clientFirstName,
clients.clientLastName,
/* select and sum the savings, then times by 0.1 to get 10% */
SUM(savings.amountSaved)*0.10 as TotalAmountSaved
from clients
/*join accounts to clients so we can get savings */
left JOIN accounts
on clients.clientID=accounts.clientID
/*join savings so we can get total amount */
left join savings
on accounts.savingID=savings.savingID
/*only get single client */
where CONCAT(clients.clientFirstName," ", clients.clientLastName) LIKE CONCAT('%', searchStr, '%')
/* group by client */
group by clients.clientID;
end$$
DELIMITER ;